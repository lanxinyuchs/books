#!/bin/sh

# Empty example init script
