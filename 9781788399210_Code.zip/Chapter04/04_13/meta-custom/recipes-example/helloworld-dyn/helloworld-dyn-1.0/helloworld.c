#include <stdio.h>
#include "helloworld.h"

int main (void)
{
	  return printf("%s %s\n",hello(),world());
}
