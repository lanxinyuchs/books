char * hello (void)
{
	  return "Hello";
}
