#ifndef HELLOWORLD_H
#define HELLOWORLD_H
char * hello (void);
char * world (void);
#endif
