import sys
from setuptools import setup

setup(
        name = "helloworld",
        version = "0.1",
        packages=["helloworld"],
        author="Alex Gonzalez",
        author_email = "alex@example.com",
        description = "Hello World packaging example",
        license = "MIT",
        keywords= "example",
        url = "",
)
