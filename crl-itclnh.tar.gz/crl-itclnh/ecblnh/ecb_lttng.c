#define TRACEPOINT_CREATE_PROBES
#include "ecb_lttng.h"

