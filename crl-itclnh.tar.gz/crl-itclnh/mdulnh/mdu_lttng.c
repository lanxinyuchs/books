#ifdef LTTNG
#define TRACEPOINT_CREATE_PROBES
#include "mdu_lttng.h"
#endif

