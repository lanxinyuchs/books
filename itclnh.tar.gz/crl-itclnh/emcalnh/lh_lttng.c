#ifdef LTTNG
#define TRACEPOINT_CREATE_PROBES
#include "lh_lttng.h"
#endif

